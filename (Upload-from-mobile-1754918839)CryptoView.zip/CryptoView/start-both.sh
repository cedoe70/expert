#!/bin/bash
echo "Starting both servers..."
concurrently \
  "npm run dev" \
  "cd nextjs-backend && npx next dev -p 3001" \
  --names "Frontend,NextJS-API" \
  --prefix-colors "blue,green"
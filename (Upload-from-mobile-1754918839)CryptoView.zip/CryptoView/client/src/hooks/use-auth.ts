import { useState, useEffect } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface User {
  id: string;
  username: string;
  email: string;
  kycStatus: 'pending' | 'approved' | 'rejected';
}

interface RegisterData {
  username: string;
  email: string;
  password: string;
  firstName?: string;
  lastName?: string;
}

export function useAuth() {
  const [sessionId, setSessionId] = useState<string | null>(() => 
    localStorage.getItem('crypto_session_id')
  );
  const [user, setUser] = useState<User | null>(null);
  const queryClient = useQueryClient();

  // Fetch current user if we have a session
  const { data: currentUser, refetch: refetchUser } = useQuery({
    queryKey: ['/api/auth/user'],
    queryFn: async () => {
      if (!sessionId) return null;
      const response = await fetch('/api/auth/user', {
        headers: {
          'Authorization': `Bearer ${sessionId}`
        }
      });
      if (!response.ok) {
        // Session is invalid, clear it
        setSessionId(null);
        localStorage.removeItem('crypto_session_id');
        setUser(null);
        return null;
      }
      const userData = await response.json();
      return userData;
    },
    enabled: !!sessionId,
    retry: false,
    staleTime: 0, // Always fetch fresh data
  });

  // Update user state when currentUser changes
  useEffect(() => {
    if (currentUser) {
      setUser(currentUser);
    } else if (!sessionId) {
      setUser(null);
    }
  }, [currentUser, sessionId]);

  const loginMutation = useMutation({
    mutationFn: async ({ username, password }: { username: string; password: string }) => {
      const response = await apiRequest('POST', '/api/auth/login', { username, password });
      return await response.json();
    },
    onSuccess: (data: any) => {
      if (data.success) {
        const newSessionId = data.sessionId;
        setSessionId(newSessionId);
        setUser(data.user);
        localStorage.setItem('crypto_session_id', newSessionId);
        // Invalidate all queries to refresh data
        queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
        queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      }
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: RegisterData) => {
      const response = await apiRequest('POST', '/api/auth/register', data);
      return await response.json();
    },
    onSuccess: (data: any) => {
      if (data.success) {
        const newSessionId = data.sessionId;
        setSessionId(newSessionId);
        setUser(data.user);
        localStorage.setItem('crypto_session_id', newSessionId);
        // Invalidate all queries to refresh data
        queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
        queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      }
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      if (!sessionId) return;
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${sessionId}`,
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });
      if (!response.ok) {
        throw new Error('Logout failed');
      }
      return await response.json();
    },
    onSuccess: () => {
      setSessionId(null);
      setUser(null);
      localStorage.removeItem('crypto_session_id');
      queryClient.clear();
    },
  });

  const login = async (username: string, password: string) => {
    await loginMutation.mutateAsync({ username, password });
  };

  const register = async (data: RegisterData) => {
    await registerMutation.mutateAsync(data);
  };

  const logout = async () => {
    await logoutMutation.mutateAsync();
  };

  return {
    user,
    sessionId,
    isAuthenticated: !!user && !!sessionId,
    isLoading: loginMutation.isPending || registerMutation.isPending || logoutMutation.isPending,
    login,
    register,
    logout,
    loginError: loginMutation.error,
    registerError: registerMutation.error,
  };
}
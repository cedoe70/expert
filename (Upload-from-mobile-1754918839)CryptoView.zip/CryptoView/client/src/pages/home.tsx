import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import PriceTicker from "@/components/price-ticker";
import MarketOverview from "@/components/market-overview";
import FeaturesSection from "@/components/features-section";
import AboutSection from "@/components/about-section";
import NewsletterSection from "@/components/newsletter-section";
import Footer from "@/components/footer";
import ScrollToTop from "@/components/scroll-to-top";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Navigation />
      <HeroSection />
      <PriceTicker />
      <MarketOverview />
      <FeaturesSection />
      <AboutSection />
      <NewsletterSection />
      <Footer />
      <ScrollToTop />
    </div>
  );
}

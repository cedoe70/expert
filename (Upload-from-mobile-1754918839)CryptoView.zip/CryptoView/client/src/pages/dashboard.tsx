import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { 
  Wallet, 
  TrendingUp, 
  Plus, 
  Minus, 
  Shield, 
  User, 
  History,
  Eye,
  EyeOff,
  LogOut,
  Settings
} from "lucide-react";
import DepositForm from "@/components/deposit-form";
import WithdrawForm from "@/components/withdraw-form";
import KYCForm from "@/components/kyc-form";

interface UserBalance {
  id: string;
  currency: string;
  balance: string;
  availableBalance: string;
  lockedBalance: string;
}

interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal';
  currency: string;
  amount: string;
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
  createdAt: string;
  txHash?: string;
  address?: string;
}

export default function DashboardPage() {
  const { user, sessionId, logout, isAuthenticated } = useAuth();
  const [showBalances, setShowBalances] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch user balances
  const { data: balancesData, isLoading: balancesLoading } = useQuery({
    queryKey: ['/api/user/balances'],
    queryFn: async () => {
      const response = await fetch('/api/user/balances', {
        headers: {
          'Authorization': `Bearer ${sessionId}`
        }
      });
      return await response.json();
    },
    enabled: !!sessionId && isAuthenticated,
  });

  // Fetch transactions
  const { data: transactionsData, isLoading: transactionsLoading } = useQuery({
    queryKey: ['/api/user/transactions'],
    queryFn: async () => {
      const response = await fetch('/api/user/transactions', {
        headers: {
          'Authorization': `Bearer ${sessionId}`
        }
      });
      return await response.json();
    },
    enabled: !!sessionId && isAuthenticated,
  });

  // Fetch KYC status
  const { data: kycData } = useQuery({
    queryKey: ['/api/user/kyc'],
    queryFn: async () => {
      const response = await fetch('/api/user/kyc', {
        headers: {
          'Authorization': `Bearer ${sessionId}`
        }
      });
      return await response.json();
    },
    enabled: !!sessionId && isAuthenticated,
  });

  // Show loading while checking authentication
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  const balances: UserBalance[] = balancesData?.balances || [];
  const transactions: Transaction[] = transactionsData?.transactions || [];
  const kycStatus = user?.kycStatus || 'pending';

  const getTotalUSDValue = () => {
    const usdBalance = balances.find(b => b.currency === 'USD');
    return parseFloat(usdBalance?.balance || '0');
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      pending: "outline",
      completed: "default",
      approved: "default",
      failed: "destructive",
      cancelled: "secondary",
      rejected: "destructive"
    };
    
    return (
      <Badge variant={variants[status] || "outline"}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  if (!user || !sessionId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <Card className="w-full max-w-md bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6 text-center">
            <p className="text-white mb-4">Please log in to access your dashboard</p>
            <Link href="/login">
              <Button>Go to Login</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="border-b border-slate-700/50 bg-slate-800/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <h1 className="text-xl font-bold text-white">CryptoFlow</h1>
              </Link>
              <Badge variant="secondary" className="text-xs">
                Dashboard
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-sm text-slate-400">
                Welcome, <span className="text-white font-medium">{user.username}</span>
              </div>
              <Button
                onClick={logout}
                variant="outline"
                size="sm"
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                <LogOut className="h-4 w-4 mr-1" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* KYC Notice */}
        {kycStatus !== 'approved' && (
          <Card className="mb-6 bg-blue-900/20 border-blue-700/50">
            <CardContent className="pt-6">
              <div className="flex items-center space-x-3">
                <Shield className="h-5 w-5 text-blue-400" />
                <div>
                  <h3 className="text-blue-300 font-medium">KYC Verification Required</h3>
                  <p className="text-slate-400 text-sm">
                    Complete your identity verification to unlock full trading features and higher limits.
                  </p>
                </div>
                <Button
                  onClick={() => setActiveTab("kyc")}
                  variant="outline"
                  size="sm"
                  className="border-blue-600 text-blue-400 hover:bg-blue-900/50"
                >
                  Verify Now
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Portfolio Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">
                Total Portfolio Value
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowBalances(!showBalances)}
                className="h-8 w-8 p-0 text-slate-400 hover:text-white"
              >
                {showBalances ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
              </Button>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {showBalances ? `$${getTotalUSDValue().toFixed(2)}` : '••••••'}
              </div>
              <p className="text-xs text-slate-400">
                USD Equivalent
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">
                KYC Status
              </CardTitle>
              <Shield className="h-4 w-4 text-slate-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white mb-1">
                {getStatusBadge(kycStatus)}
              </div>
              <p className="text-xs text-slate-400">
                Identity Verification
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-400">
                Active Assets
              </CardTitle>
              <Wallet className="h-4 w-4 text-slate-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {balances.filter(b => parseFloat(b.balance) > 0).length}
              </div>
              <p className="text-xs text-slate-400">
                Cryptocurrencies
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-slate-800/50 border-slate-700 mb-6">
            <TabsTrigger value="overview" className="data-[state=active]:bg-slate-700">
              Overview
            </TabsTrigger>
            <TabsTrigger value="deposit" className="data-[state=active]:bg-slate-700">
              Deposit
            </TabsTrigger>
            <TabsTrigger value="withdraw" className="data-[state=active]:bg-slate-700">
              Withdraw
            </TabsTrigger>
            <TabsTrigger value="kyc" className="data-[state=active]:bg-slate-700">
              KYC
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-slate-700">
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Balances */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Asset Balances</CardTitle>
                  <CardDescription>Your cryptocurrency holdings</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {balances.map((balance) => (
                      <div key={balance.id} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center">
                            <span className="text-xs font-medium text-white">
                              {balance.currency.slice(0, 2)}
                            </span>
                          </div>
                          <div>
                            <p className="text-white font-medium">{balance.currency}</p>
                            <p className="text-slate-400 text-sm">
                              Available: {showBalances ? balance.availableBalance : '••••••'}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-white font-medium">
                            {showBalances ? balance.balance : '••••••'}
                          </p>
                          {parseFloat(balance.lockedBalance) > 0 && (
                            <p className="text-orange-400 text-sm">
                              Locked: {showBalances ? balance.lockedBalance : '••••••'}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Recent Transactions */}
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Recent Activity</CardTitle>
                  <CardDescription>Your latest transactions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {transactions.slice(0, 5).map((tx) => (
                      <div key={tx.id} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            tx.type === 'deposit' ? 'bg-green-900/50' : 'bg-red-900/50'
                          }`}>
                            {tx.type === 'deposit' ? 
                              <Plus className="h-4 w-4 text-green-400" /> :
                              <Minus className="h-4 w-4 text-red-400" />
                            }
                          </div>
                          <div>
                            <p className="text-white font-medium capitalize">
                              {tx.type} {tx.currency}
                            </p>
                            <p className="text-slate-400 text-sm">
                              {new Date(tx.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`font-medium ${
                            tx.type === 'deposit' ? 'text-green-400' : 'text-red-400'
                          }`}>
                            {tx.type === 'deposit' ? '+' : '-'}{tx.amount}
                          </p>
                          {getStatusBadge(tx.status)}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="deposit">
            <DepositForm />
          </TabsContent>

          <TabsContent value="withdraw">
            <WithdrawForm />
          </TabsContent>

          <TabsContent value="kyc">
            <KYCForm />
          </TabsContent>

          <TabsContent value="history">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Transaction History</CardTitle>
                <CardDescription>Complete history of your transactions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {transactions.map((tx) => (
                    <div key={tx.id} className="border border-slate-700 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-3">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            tx.type === 'deposit' ? 'bg-green-900/50' : 'bg-red-900/50'
                          }`}>
                            {tx.type === 'deposit' ? 
                              <Plus className="h-5 w-5 text-green-400" /> :
                              <Minus className="h-5 w-5 text-red-400" />
                            }
                          </div>
                          <div>
                            <p className="text-white font-medium capitalize">
                              {tx.type} {tx.currency}
                            </p>
                            <p className="text-slate-400 text-sm">
                              {new Date(tx.createdAt).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`font-medium text-lg ${
                            tx.type === 'deposit' ? 'text-green-400' : 'text-red-400'
                          }`}>
                            {tx.type === 'deposit' ? '+' : '-'}{tx.amount} {tx.currency}
                          </p>
                          {getStatusBadge(tx.status)}
                        </div>
                      </div>
                      {tx.txHash && (
                        <p className="text-slate-400 text-sm font-mono">
                          TX: {tx.txHash}
                        </p>
                      )}
                      {tx.address && (
                        <p className="text-slate-400 text-sm">
                          To: {tx.address}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
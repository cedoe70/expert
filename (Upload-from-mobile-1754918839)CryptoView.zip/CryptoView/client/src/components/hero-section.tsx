import { Shield, Users, Clock, TrendingUp, Zap, Star } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function HeroSection() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-900/20 to-slate-900"></div>
      <div className="absolute inset-0 opacity-40" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.02'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
      }}></div>
      
      {/* Floating elements with enhanced animations */}
      <motion.div 
        className="absolute top-20 left-10 w-20 h-20 bg-blue-500/10 rounded-full border border-blue-500/20 backdrop-blur-sm"
        animate={{ 
          y: [0, -20, 0],
          rotate: [0, 180, 360],
          scale: [1, 1.1, 1]
        }}
        transition={{ 
          duration: 8, 
          repeat: Infinity, 
          ease: "easeInOut" 
        }}
      >
        <div className="w-full h-full flex items-center justify-center">
          <TrendingUp className="w-8 h-8 text-blue-400" />
        </div>
      </motion.div>
      
      <motion.div 
        className="absolute top-40 right-20 w-16 h-16 bg-purple-500/10 rounded-full border border-purple-500/20 backdrop-blur-sm"
        animate={{ 
          y: [0, 20, 0],
          x: [0, -10, 0],
          scale: [1, 1.2, 1]
        }}
        transition={{ 
          duration: 6, 
          repeat: Infinity, 
          ease: "easeInOut",
          delay: 2
        }}
      >
        <div className="w-full h-full flex items-center justify-center">
          <Zap className="w-6 h-6 text-purple-400" />
        </div>
      </motion.div>
      
      <motion.div 
        className="absolute bottom-40 left-20 w-12 h-12 bg-green-500/10 rounded-full border border-green-500/20 backdrop-blur-sm"
        animate={{ 
          y: [0, -15, 0],
          x: [0, 15, 0],
          rotate: [0, -180, -360]
        }}
        transition={{ 
          duration: 7, 
          repeat: Infinity, 
          ease: "easeInOut",
          delay: 4
        }}
      >
        <div className="w-full h-full flex items-center justify-center">
          <Star className="w-4 h-4 text-green-400" />
        </div>
      </motion.div>

      {/* Additional floating particles */}
      <motion.div 
        className="absolute top-60 right-40 w-6 h-6 bg-yellow-500/20 rounded-full"
        animate={{ 
          y: [0, -30, 0],
          opacity: [0.3, 1, 0.3]
        }}
        transition={{ 
          duration: 4, 
          repeat: Infinity, 
          ease: "easeInOut",
          delay: 1
        }}
      />
      
      <motion.div 
        className="absolute bottom-60 right-10 w-8 h-8 bg-pink-500/20 rounded-full"
        animate={{ 
          x: [0, -20, 0],
          y: [0, 10, 0],
          scale: [1, 1.3, 1]
        }}
        transition={{ 
          duration: 5, 
          repeat: Infinity, 
          ease: "easeInOut",
          delay: 3
        }}
      />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <motion.h1 
            className="text-4xl sm:text-6xl lg:text-7xl font-bold mb-6 leading-tight"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            The Future of
            <motion.span 
              className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-400 to-blue-600 ml-4 block sm:inline"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.5 }}
            >
              Digital Assets
            </motion.span>
          </motion.h1>
          
          <motion.p 
            className="text-xl sm:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Trade, invest, and manage your cryptocurrency portfolio with confidence. 
            Join millions of users who trust CryptoFlow for their digital asset journey.
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <Link href="/register">
              <motion.button 
                className="group w-full sm:w-auto bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-lg text-lg font-semibold relative overflow-hidden"
                whileHover={{ 
                  scale: 1.05,
                  boxShadow: "0 20px 40px rgba(59, 130, 246, 0.3)"
                }}
                whileTap={{ scale: 0.95 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <span className="relative z-10">Start Trading Now</span>
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 opacity-0 group-hover:opacity-100"
                  initial={false}
                  transition={{ duration: 0.3 }}
                />
              </motion.button>
            </Link>
            <Link href="#about">
              <motion.button 
                className="group w-full sm:w-auto border-2 border-gray-600 text-gray-300 px-8 py-4 rounded-lg text-lg font-semibold relative overflow-hidden"
                whileHover={{ 
                  borderColor: "#3b82f6",
                  color: "#3b82f6",
                  scale: 1.02
                }}
                whileTap={{ scale: 0.98 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                Learn More
              </motion.button>
            </Link>
          </motion.div>
          
          {/* Trust indicators with staggered animation */}
          <motion.div 
            className="flex flex-wrap items-center justify-center gap-8 text-gray-400"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            {[
              { icon: Shield, text: "Bank-level Security", delay: 0 },
              { icon: Users, text: "10M+ Users", delay: 0.1 },
              { icon: Clock, text: "24/7 Support", delay: 0.2 }
            ].map(({ icon: Icon, text, delay }, index) => (
              <motion.div 
                key={index}
                className="flex items-center space-x-2 group cursor-pointer"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.8 + delay }}
                whileHover={{ 
                  scale: 1.05,
                  color: "#3b82f6"
                }}
              >
                <motion.div
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.5 }}
                >
                  <Icon className="text-blue-400 h-5 w-5 group-hover:text-blue-300" />
                </motion.div>
                <span className="group-hover:text-blue-300 transition-colors">{text}</span>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

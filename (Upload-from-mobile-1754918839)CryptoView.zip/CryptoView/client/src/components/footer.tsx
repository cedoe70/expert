import { TrendingUp } from "lucide-react";
import { SiX, SiLinkedin, SiGithub, SiDiscord } from "react-icons/si";

export default function Footer() {
  const productLinks = [
    "Spot Trading", "Futures Trading", "Margin Trading", "Staking", "NFT Marketplace"
  ];

  const supportLinks = [
    "Help Center", "Contact Us", "API Documentation", "Trading Fees", "Status Page"
  ];

  const legalLinks = [
    "Privacy Policy", "Terms of Service", "Cookie Policy", "Risk Disclosure", "Compliance"
  ];

  return (
    <footer className="bg-gray-800 border-t border-gray-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <TrendingUp className="text-primary text-2xl" />
              <span className="text-xl font-bold">CryptoFlow</span>
            </div>
            <p className="text-gray-400 mb-6">
              The world's leading cryptocurrency trading platform, 
              trusted by millions of users worldwide.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <SiX className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <SiLinkedin className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <SiGithub className="text-xl" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <SiDiscord className="text-xl" />
              </a>
            </div>
          </div>
          
          {/* Products */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Products</h3>
            <ul className="space-y-4">
              {productLinks.map((link, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Support */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Support</h3>
            <ul className="space-y-4">
              {supportLinks.map((link, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Legal */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Legal</h3>
            <ul className="space-y-4">
              {legalLinks.map((link, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-12 pt-8">
          <div className="flex flex-col sm:flex-row items-center justify-between">
            <p className="text-gray-400 text-sm">
              © 2024 CryptoFlow. All rights reserved.
            </p>
            <div className="flex items-center space-x-6 mt-4 sm:mt-0">
              <span className="text-gray-400 text-sm">🌍 Global</span>
              <span className="text-gray-400 text-sm">🔒 Secure</span>
              <span className="text-gray-400 text-sm">⚡ Fast</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Minus, MapPin, AlertTriangle } from "lucide-react";

const withdrawSchema = z.object({
  currency: z.string().min(1, "Please select a currency"),
  amount: z.string().refine((val) => !isNaN(Number(val)) && Number(val) > 0, {
    message: "Amount must be a positive number",
  }),
  address: z.string().min(1, "Please enter a valid wallet address"),
});

type WithdrawForm = z.infer<typeof withdrawSchema>;

const currencies = [
  { value: "BTC", label: "Bitcoin (BTC)" },
  { value: "ETH", label: "Ethereum (ETH)" },
  { value: "BNB", label: "BNB (BNB)" },
  { value: "ADA", label: "Cardano (ADA)" },
  { value: "SOL", label: "Solana (SOL)" },
  { value: "USD", label: "US Dollar (USD)" },
];

export default function WithdrawForm() {
  const { sessionId } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<WithdrawForm>({
    resolver: zodResolver(withdrawSchema),
    defaultValues: {
      currency: "",
      amount: "",
      address: "",
    },
  });

  const withdrawMutation = useMutation({
    mutationFn: async (data: WithdrawForm) => {
      const response = await fetch('/api/user/withdraw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionId}`
        },
        body: JSON.stringify(data),
      });
      return await response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "Withdrawal Submitted",
          description: data.message,
        });
        form.reset();
        queryClient.invalidateQueries({ queryKey: ['/api/user/balances'] });
        queryClient.invalidateQueries({ queryKey: ['/api/user/transactions'] });
      } else {
        toast({
          title: "Withdrawal Failed",
          description: data.message || "Failed to process withdrawal",
          variant: "destructive",
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Withdrawal Failed",
        description: error.message || "Failed to process withdrawal",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: WithdrawForm) => {
    await withdrawMutation.mutateAsync(data);
  };

  return (
    <Card className="bg-slate-800/50 border-slate-700 max-w-2xl">
      <CardHeader>
        <div className="flex items-center space-x-2">
          <Minus className="h-5 w-5 text-red-400" />
          <CardTitle className="text-white">Withdraw Funds</CardTitle>
        </div>
        <CardDescription>
          Transfer your cryptocurrency to an external wallet. Review all details carefully.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="currency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">Currency</FormLabel>
                  <FormControl>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue placeholder="Select currency to withdraw" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-700 border-slate-600">
                        {currencies.map((currency) => (
                          <SelectItem
                            key={currency.value}
                            value={currency.value}
                            className="text-white hover:bg-slate-600"
                          >
                            {currency.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage className="text-red-400" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">Amount</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="number"
                      step="0.00000001"
                      placeholder="Enter amount to withdraw"
                      className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 focus:border-red-500"
                    />
                  </FormControl>
                  <FormMessage className="text-red-400" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">Wallet Address</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type="text"
                        placeholder="Enter destination wallet address"
                        className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 focus:border-red-500 pl-10"
                      />
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                    </div>
                  </FormControl>
                  <FormMessage className="text-red-400" />
                </FormItem>
              )}
            />

            <div className="bg-red-900/20 border border-red-700/50 p-4 rounded-lg">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="h-5 w-5 text-red-400 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="text-red-300 font-medium mb-2">Important Withdrawal Information</h4>
                  <ul className="text-red-200/80 text-sm space-y-1">
                    <li>• Double-check the wallet address - transactions cannot be reversed</li>
                    <li>• Ensure the address matches the selected currency network</li>
                    <li>• Withdrawals may take 5-30 minutes to process</li>
                    <li>• Minimum withdrawal amounts and fees apply</li>
                    <li>• For demo purposes, funds will be locked pending review</li>
                  </ul>
                </div>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-red-600 hover:bg-red-700 text-white"
              disabled={withdrawMutation.isPending}
            >
              {withdrawMutation.isPending ? "Processing Withdrawal..." : "Confirm Withdrawal"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
import { motion } from "framer-motion";
import { TrendingUp, TrendingDown } from "lucide-react";

export default function PriceTicker() {
  const cryptoData = [
    { symbol: "BTC", price: "$43,250.00", change: "+2.34%", isPositive: true },
    { symbol: "ETH", price: "$2,650.00", change: "+1.87%", isPositive: true },
    { symbol: "BNB", price: "$315.40", change: "-0.92%", isPositive: false },
    { symbol: "ADA", price: "$0.48", change: "+3.21%", isPositive: true },
    { symbol: "SOL", price: "$95.30", change: "+5.67%", isPositive: true },
  ];

  // Duplicate data for seamless scrolling
  const extendedData = [...cryptoData, ...cryptoData, ...cryptoData];

  return (
    <div className="bg-gray-800/90 backdrop-blur-sm border-y border-gray-700/50 py-4 overflow-hidden relative">
      {/* Gradient overlays for smooth fade effect */}
      <div className="absolute left-0 top-0 w-20 h-full bg-gradient-to-r from-gray-800 to-transparent z-10"></div>
      <div className="absolute right-0 top-0 w-20 h-full bg-gradient-to-l from-gray-800 to-transparent z-10"></div>
      
      <motion.div 
        className="flex space-x-8 text-sm"
        animate={{ x: ["0%", "-33.33%"] }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear"
        }}
        style={{ width: "300%" }}
      >
        {extendedData.map((crypto, index) => (
          <motion.div 
            key={index} 
            className="flex items-center space-x-2 whitespace-nowrap group cursor-pointer"
            whileHover={{ 
              scale: 1.05,
              backgroundColor: "rgba(59, 130, 246, 0.1)"
            }}
            transition={{ duration: 0.2 }}
          >
            <motion.span 
              className="font-semibold text-gray-200 group-hover:text-blue-400"
              whileHover={{ color: "#3b82f6" }}
            >
              {crypto.symbol}
            </motion.span>
            <motion.span 
              className={crypto.isPositive ? "text-green-400" : "text-red-400"}
              whileHover={{ scale: 1.1 }}
            >
              {crypto.price}
            </motion.span>
            <motion.div 
              className={`flex items-center text-xs ${crypto.isPositive ? "text-green-400" : "text-red-400"}`}
              whileHover={{ scale: 1.1 }}
            >
              {crypto.isPositive ? (
                <TrendingUp className="w-3 h-3 mr-1" />
              ) : (
                <TrendingDown className="w-3 h-3 mr-1" />
              )}
              <span>{crypto.change}</span>
            </motion.div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}

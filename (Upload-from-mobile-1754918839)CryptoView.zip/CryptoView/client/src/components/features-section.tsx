import { Shield, Zap, TrendingUp, Smartphone, DollarSign, Headphones } from "lucide-react";
import { motion } from "framer-motion";

export default function FeaturesSection() {
  const features = [
    {
      icon: Shield,
      title: "Military-Grade Security",
      description: "Your assets are protected with advanced encryption, multi-signature wallets, and cold storage solutions trusted by institutions worldwide.",
      color: "text-primary",
      bgColor: "bg-primary/20 group-hover:bg-primary/30"
    },
    {
      icon: Zap,
      title: "Lightning-Fast Trading",
      description: "Execute trades in milliseconds with our high-performance matching engine and low-latency infrastructure for optimal trading outcomes.",
      color: "text-accent",
      bgColor: "bg-accent/20 group-hover:bg-accent/30"
    },
    {
      icon: TrendingUp,
      title: "Advanced Analytics",
      description: "Make informed decisions with professional charting tools, technical indicators, and real-time market analysis powered by AI.",
      color: "text-warning",
      bgColor: "bg-warning/20 group-hover:bg-warning/30"
    },
    {
      icon: Smartphone,
      title: "Mobile Trading",
      description: "Trade on-the-go with our award-winning mobile apps for iOS and Android, featuring full functionality and seamless synchronization.",
      color: "text-purple-400",
      bgColor: "bg-purple-500/20 group-hover:bg-purple-500/30"
    },
    {
      icon: DollarSign,
      title: "Low Fees",
      description: "Maximize your profits with industry-leading low trading fees starting at 0.1% and volume-based discounts for active traders.",
      color: "text-green-400",
      bgColor: "bg-green-500/20 group-hover:bg-green-500/30"
    },
    {
      icon: Headphones,
      title: "24/7 Support",
      description: "Get help whenever you need it with our round-the-clock customer support via chat, email, and phone from cryptocurrency experts.",
      color: "text-blue-400",
      bgColor: "bg-blue-500/20 group-hover:bg-blue-500/30"
    }
  ];

  return (
    <section id="features" className="py-20 bg-gray-800 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-20 right-20 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-20 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <motion.h2 
            className="text-3xl sm:text-4xl font-bold mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Why Choose CryptoFlow?
          </motion.h2>
          <motion.p 
            className="text-gray-400 text-lg max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            Experience the most advanced and secure cryptocurrency trading platform 
            with cutting-edge features designed for both beginners and professionals.
          </motion.p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <motion.div 
                key={index}
                className="group bg-gray-900/50 backdrop-blur-sm rounded-xl p-8 transition-all duration-300 border border-gray-700/50 hover:border-blue-500/50 relative overflow-hidden"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: 0.5, 
                  delay: index * 0.1,
                  ease: "easeOut"
                }}
                whileHover={{ 
                  scale: 1.05,
                  y: -10,
                  boxShadow: "0 20px 40px rgba(0,0,0,0.3)"
                }}
                viewport={{ once: true }}
              >
                {/* Hover effect background */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 opacity-0"
                  whileHover={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                />
                
                <motion.div 
                  className={`w-16 h-16 ${feature.bgColor} rounded-lg flex items-center justify-center mb-6 transition-all duration-300 relative`}
                  whileHover={{ 
                    scale: 1.1,
                    rotate: 5
                  }}
                >
                  <motion.div
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.5 }}
                  >
                    <IconComponent className={`${feature.color} text-2xl h-8 w-8`} />
                  </motion.div>
                </motion.div>
                
                <motion.h3 
                  className="text-xl font-semibold mb-4 relative"
                  whileHover={{ color: "#3b82f6" }}
                  transition={{ duration: 0.2 }}
                >
                  {feature.title}
                </motion.h3>
                
                <p className="text-gray-400 relative">
                  {feature.description}
                </p>

                {/* Shimmer effect on hover */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full"
                  whileHover={{ x: "200%" }}
                  transition={{ duration: 0.6 }}
                />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

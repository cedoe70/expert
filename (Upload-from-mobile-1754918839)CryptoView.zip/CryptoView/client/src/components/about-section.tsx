import { motion } from "framer-motion";

export default function AboutSection() {
  const stats = [
    { value: "10M+", label: "Trusted Users", color: "text-blue-400" },
    { value: "150+", label: "Countries Served", color: "text-green-400" },
    { value: "$2.5B", label: "Daily Volume", color: "text-yellow-400" },
    { value: "99.9%", label: "Uptime", color: "text-purple-400" }
  ];

  return (
    <section id="about" className="py-20 bg-gray-900 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-blue-500/5 to-transparent"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-purple-500/5 to-transparent"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <motion.h2 
              className="text-3xl sm:text-4xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
            >
              Building the Future of 
              <motion.span 
                className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 ml-2 block sm:inline"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.5 }}
                viewport={{ once: true }}
              >
                Finance
              </motion.span>
            </motion.h2>
            
            <motion.p 
              className="text-gray-400 text-lg mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              viewport={{ once: true }}
            >
              Since 2018, CryptoFlow has been at the forefront of the cryptocurrency revolution, 
              providing secure, reliable, and innovative solutions for digital asset trading and management.
            </motion.p>
            
            <motion.p 
              className="text-gray-400 text-lg mb-8"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              viewport={{ once: true }}
            >
              Our mission is to democratize access to cryptocurrency markets and empower individuals 
              worldwide to participate in the decentralized economy with confidence and ease.
            </motion.p>
            
            {/* Stats */}
            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <motion.div 
                  key={index}
                  className="group cursor-pointer"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.8 + index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  viewport={{ once: true }}
                >
                  <motion.h3 
                    className={`text-3xl font-bold ${stat.color} mb-2 group-hover:scale-110 transition-transform`}
                    whileHover={{ scale: 1.1 }}
                  >
                    {stat.value}
                  </motion.h3>
                  <p className="text-gray-400 group-hover:text-gray-300 transition-colors">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
          
          <motion.div 
            className="relative"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <motion.div
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.3 }}
            >
              <img 
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Modern cryptocurrency trading office with multiple monitors displaying charts" 
                className="rounded-xl shadow-2xl w-full h-auto border border-gray-700/50" 
              />
            </motion.div>
            
            {/* Floating elements with enhanced animations */}
            <motion.div 
              className="absolute -top-8 -left-8 w-16 h-16 bg-blue-500/20 rounded-full border border-blue-500/30 backdrop-blur-sm flex items-center justify-center"
              animate={{ 
                y: [0, -10, 0],
                rotate: [0, 180, 360],
                scale: [1, 1.1, 1]
              }}
              transition={{ 
                duration: 6, 
                repeat: Infinity, 
                ease: "easeInOut" 
              }}
            >
              <div className="w-6 h-6 bg-blue-400 rounded-full"></div>
            </motion.div>
            
            <motion.div 
              className="absolute -bottom-8 -right-8 w-20 h-20 bg-purple-500/20 rounded-full border border-purple-500/30 backdrop-blur-sm flex items-center justify-center"
              animate={{ 
                y: [0, 15, 0],
                x: [0, -10, 0],
                scale: [1, 1.2, 1]
              }}
              transition={{ 
                duration: 8, 
                repeat: Infinity, 
                ease: "easeInOut",
                delay: 2
              }}
            >
              <div className="w-8 h-8 bg-purple-400 rounded-full"></div>
            </motion.div>
            
            {/* Additional decorative elements */}
            <motion.div 
              className="absolute top-1/2 -right-4 w-4 h-4 bg-yellow-400/60 rounded-full"
              animate={{ 
                opacity: [0.4, 1, 0.4],
                scale: [1, 1.5, 1]
              }}
              transition={{ 
                duration: 3, 
                repeat: Infinity, 
                ease: "easeInOut"
              }}
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}

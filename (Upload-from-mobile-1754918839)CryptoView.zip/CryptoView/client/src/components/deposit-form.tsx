import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Plus, Wallet } from "lucide-react";

const depositSchema = z.object({
  currency: z.string().min(1, "Please select a currency"),
  amount: z.string().refine((val) => !isNaN(Number(val)) && Number(val) > 0, {
    message: "Amount must be a positive number",
  }),
});

type DepositForm = z.infer<typeof depositSchema>;

const currencies = [
  { value: "BTC", label: "Bitcoin (BTC)" },
  { value: "ETH", label: "Ethereum (ETH)" },
  { value: "BNB", label: "BNB (BNB)" },
  { value: "ADA", label: "Cardano (ADA)" },
  { value: "SOL", label: "Solana (SOL)" },
  { value: "USD", label: "US Dollar (USD)" },
];

export default function DepositForm() {
  const { sessionId } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<DepositForm>({
    resolver: zodResolver(depositSchema),
    defaultValues: {
      currency: "",
      amount: "",
    },
  });

  const depositMutation = useMutation({
    mutationFn: async (data: DepositForm) => {
      const response = await fetch('/api/user/deposit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionId}`
        },
        body: JSON.stringify(data),
      });
      return await response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "Deposit Successful",
          description: data.message,
        });
        form.reset();
        queryClient.invalidateQueries({ queryKey: ['/api/user/balances'] });
        queryClient.invalidateQueries({ queryKey: ['/api/user/transactions'] });
      } else {
        toast({
          title: "Deposit Failed",
          description: data.message || "Failed to process deposit",
          variant: "destructive",
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Deposit Failed",
        description: error.message || "Failed to process deposit",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: DepositForm) => {
    await depositMutation.mutateAsync(data);
  };

  return (
    <Card className="bg-slate-800/50 border-slate-700 max-w-2xl">
      <CardHeader>
        <div className="flex items-center space-x-2">
          <Plus className="h-5 w-5 text-green-400" />
          <CardTitle className="text-white">Deposit Funds</CardTitle>
        </div>
        <CardDescription>
          Add cryptocurrency to your account. Deposits are processed instantly.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="currency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">Currency</FormLabel>
                  <FormControl>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue placeholder="Select currency to deposit" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-700 border-slate-600">
                        {currencies.map((currency) => (
                          <SelectItem
                            key={currency.value}
                            value={currency.value}
                            className="text-white hover:bg-slate-600"
                          >
                            {currency.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage className="text-red-400" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">Amount</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type="number"
                        step="0.00000001"
                        placeholder="Enter amount to deposit"
                        className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 focus:border-green-500 pl-10"
                      />
                      <Wallet className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                    </div>
                  </FormControl>
                  <FormMessage className="text-red-400" />
                </FormItem>
              )}
            />

            <div className="bg-slate-700/50 p-4 rounded-lg">
              <h4 className="text-white font-medium mb-2">Important Information</h4>
              <ul className="text-slate-400 text-sm space-y-1">
                <li>• Deposits are processed instantly</li>
                <li>• Minimum deposit varies by currency</li>
                <li>• For demo purposes, this simulates a real deposit</li>
                <li>• Always verify the currency before submitting</li>
              </ul>
            </div>

            <Button
              type="submit"
              className="w-full bg-green-600 hover:bg-green-700 text-white"
              disabled={depositMutation.isPending}
            >
              {depositMutation.isPending ? "Processing Deposit..." : "Confirm Deposit"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
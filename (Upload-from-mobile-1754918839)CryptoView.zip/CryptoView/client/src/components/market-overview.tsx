import { Coins, ArrowUpDown, PieChart, Layers } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";

type CryptoPriceData = {
  symbol: string
  name: string
  price: string
  change: string
  isPositive: boolean
  marketCap: string
  volume: string
  rank: number
}

type MarketStats = {
  totalMarketCap: string
  volume24h: string
  btcDominance: string
  activeCryptocurrencies: number
}

export default function MarketOverview() {
  const { data: marketData = [], isLoading: pricesLoading } = useQuery<CryptoPriceData[]>({
    queryKey: ['/api/crypto/prices'],
    queryFn: async () => {
      const response = await fetch('/api/crypto/prices')
      if (!response.ok) {
        throw new Error('Failed to fetch crypto prices')
      }
      return response.json()
    }
  })

  const { data: marketStats, isLoading: statsLoading } = useQuery<MarketStats>({
    queryKey: ['/api/market/stats'],
    queryFn: async () => {
      const response = await fetch('/api/market/stats')
      if (!response.ok) {
        throw new Error('Failed to fetch market stats')
      }
      return response.json()
    }
  })

  const getColorForCrypto = (symbol: string) => {
    const colors: Record<string, string> = {
      BTC: "bg-orange-500",
      ETH: "bg-blue-500",
      BNB: "bg-yellow-500",
      ADA: "bg-blue-400",
      SOL: "bg-purple-500"
    }
    return colors[symbol] || "bg-gray-500"
  }

  return (
    <section id="markets" className="py-20 bg-gray-900 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <motion.h2 
            className="text-3xl sm:text-4xl font-bold mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Market Overview
          </motion.h2>
          <motion.p 
            className="text-gray-400 text-lg"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            Real-time cryptocurrency market data and analytics
          </motion.p>
        </motion.div>
        
        {/* Market Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {[
            {
              icon: Coins,
              value: statsLoading ? "Loading..." : marketStats?.totalMarketCap || "$1.7T",
              label: "Total Market Cap",
              color: "text-blue-400",
              delay: 0
            },
            {
              icon: ArrowUpDown,
              value: statsLoading ? "Loading..." : marketStats?.volume24h || "$89.2B", 
              label: "24h Volume",
              color: "text-green-400",
              delay: 0.1
            },
            {
              icon: PieChart,
              value: statsLoading ? "Loading..." : marketStats?.btcDominance || "51.2%",
              label: "BTC Dominance", 
              color: "text-yellow-400",
              delay: 0.2
            },
            {
              icon: Layers,
              value: statsLoading ? "Loading..." : marketStats?.activeCryptocurrencies || 2384,
              label: "Active Cryptocurrencies",
              color: "text-purple-400", 
              delay: 0.3
            }
          ].map((stat, index) => (
            <motion.div
              key={index}
              className="glass-morphism rounded-xl p-6 text-center relative overflow-hidden group cursor-pointer"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: stat.delay }}
              whileHover={{ 
                scale: 1.05,
                boxShadow: "0 20px 40px rgba(0,0,0,0.3)"
              }}
              viewport={{ once: true }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 opacity-0"
                whileHover={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              />
              
              <motion.div
                whileHover={{ rotate: 360, scale: 1.2 }}
                transition={{ duration: 0.5 }}
              >
                <stat.icon className={`${stat.color} text-3xl mb-4 mx-auto`} />
              </motion.div>
              
              <motion.h3 
                className="text-2xl font-bold mb-2 relative"
                whileHover={{ scale: 1.1 }}
              >
                {stat.value}
              </motion.h3>
              
              <p className="text-gray-400 relative">{stat.label}</p>
              
              {/* Shimmer effect */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full"
                whileHover={{ x: "200%" }}
                transition={{ duration: 0.6 }}
              />
            </motion.div>
          ))}
        </div>
        
        {/* Market Table */}
        <motion.div 
          className="bg-gray-800/50 backdrop-blur-sm rounded-xl overflow-hidden border border-gray-700/50"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
        >
          <div className="px-6 py-4 border-b border-gray-700/50">
            <h3 className="text-xl font-semibold">Top Cryptocurrencies</h3>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-700/50">
                <tr className="text-left text-gray-400">
                  <th className="px-6 py-4 font-medium">#</th>
                  <th className="px-6 py-4 font-medium">Name</th>
                  <th className="px-6 py-4 font-medium">Price</th>
                  <th className="px-6 py-4 font-medium">24h %</th>
                  <th className="px-6 py-4 font-medium">Market Cap</th>
                  <th className="px-6 py-4 font-medium">Volume (24h)</th>
                </tr>
              </thead>
              <tbody>
                {pricesLoading ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-8 text-center text-gray-400">
                      Loading market data...
                    </td>
                  </tr>
                ) : (
                  marketData.map((coin, index) => (
                    <motion.tr 
                      key={coin.rank} 
                      className="border-b border-gray-700/50 hover:bg-gray-700/30 transition-colors cursor-pointer"
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                      whileHover={{ backgroundColor: "rgba(59, 130, 246, 0.1)" }}
                      viewport={{ once: true }}
                    >
                      <td className="px-6 py-4 text-gray-400">{coin.rank}</td>
                      <td className="px-6 py-4">
                        <motion.div 
                          className="flex items-center space-x-3"
                          whileHover={{ scale: 1.02 }}
                        >
                          <div className={`w-8 h-8 ${getColorForCrypto(coin.symbol)} rounded-full flex items-center justify-center`}>
                            <span className="text-white font-bold text-xs">
                              {coin.symbol.slice(0, 3)}
                            </span>
                          </div>
                          <div>
                            <div className="font-semibold">{coin.name}</div>
                            <div className="text-gray-400 text-sm">{coin.symbol}</div>
                          </div>
                        </motion.div>
                      </td>
                      <td className="px-6 py-4 font-semibold">{coin.price}</td>
                      <td className="px-6 py-4">
                        <motion.span 
                          className={`font-medium ${coin.isPositive ? 'text-green-400' : 'text-red-400'}`}
                          whileHover={{ scale: 1.1 }}
                        >
                          {coin.change}
                        </motion.span>
                      </td>
                      <td className="px-6 py-4 text-gray-300">{coin.marketCap}</td>
                      <td className="px-6 py-4 text-gray-300">{coin.volume}</td>
                    </motion.tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Shield, FileText, Camera, CheckCircle } from "lucide-react";

const kycSchema = z.object({
  documentType: z.string().min(1, "Please select a document type"),
  documentNumber: z.string().min(1, "Please enter document number"),
  documentImageUrl: z.string().url().optional().or(z.literal("")),
  selfieImageUrl: z.string().url().optional().or(z.literal("")),
});

type KYCForm = z.infer<typeof kycSchema>;

const documentTypes = [
  { value: "passport", label: "Passport" },
  { value: "drivers_license", label: "Driver's License" },
  { value: "national_id", label: "National ID Card" },
  { value: "state_id", label: "State ID" },
];

export default function KYCForm() {
  const { sessionId, user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<KYCForm>({
    resolver: zodResolver(kycSchema),
    defaultValues: {
      documentType: "",
      documentNumber: "",
      documentImageUrl: "",
      selfieImageUrl: "",
    },
  });

  const kycMutation = useMutation({
    mutationFn: async (data: KYCForm) => {
      const response = await fetch('/api/user/kyc', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${sessionId}`
        },
        body: JSON.stringify(data),
      });
      return await response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "KYC Submitted",
          description: data.message,
        });
        form.reset();
        queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      } else {
        toast({
          title: "KYC Submission Failed",
          description: data.message || "Failed to submit KYC",
          variant: "destructive",
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "KYC Submission Failed",
        description: error.message || "Failed to submit KYC",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: KYCForm) => {
    await kycMutation.mutateAsync(data);
  };

  // If KYC is already approved, show success message
  if (user?.kycStatus === 'approved') {
    return (
      <Card className="bg-green-900/20 border-green-700/50 max-w-2xl">
        <CardHeader>
          <div className="flex items-center space-x-2">
            <CheckCircle className="h-5 w-5 text-green-400" />
            <CardTitle className="text-green-300">KYC Verified</CardTitle>
          </div>
          <CardDescription>
            Your identity has been successfully verified. You now have access to all features.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-3 p-4 bg-green-900/30 rounded-lg">
            <Shield className="h-8 w-8 text-green-400" />
            <div>
              <h3 className="text-green-300 font-medium">Verification Complete</h3>
              <p className="text-green-200/80 text-sm">
                You can now enjoy unrestricted trading and higher withdrawal limits.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-800/50 border-slate-700 max-w-2xl">
      <CardHeader>
        <div className="flex items-center space-x-2">
          <Shield className="h-5 w-5 text-blue-400" />
          <CardTitle className="text-white">Identity Verification (KYC)</CardTitle>
        </div>
        <CardDescription>
          Complete your identity verification to unlock full access to all platform features.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {user?.kycStatus === 'pending' ? (
          <div className="bg-yellow-900/20 border border-yellow-700/50 p-4 rounded-lg mb-6">
            <div className="flex items-center space-x-3">
              <FileText className="h-5 w-5 text-yellow-400" />
              <div>
                <h4 className="text-yellow-300 font-medium">KYC Under Review</h4>
                <p className="text-yellow-200/80 text-sm">
                  Your KYC submission is currently being reviewed. This process typically takes 1-3 business days.
                </p>
              </div>
            </div>
          </div>
        ) : user?.kycStatus === 'rejected' ? (
          <div className="bg-red-900/20 border border-red-700/50 p-4 rounded-lg mb-6">
            <div className="flex items-center space-x-3">
              <FileText className="h-5 w-5 text-red-400" />
              <div>
                <h4 className="text-red-300 font-medium">KYC Rejected</h4>
                <p className="text-red-200/80 text-sm">
                  Your previous KYC submission was rejected. Please review your information and submit again with valid documents.
                </p>
              </div>
            </div>
          </div>
        ) : null}

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="documentType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">Document Type</FormLabel>
                  <FormControl>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                        <SelectValue placeholder="Select your document type" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-700 border-slate-600">
                        {documentTypes.map((type) => (
                          <SelectItem
                            key={type.value}
                            value={type.value}
                            className="text-white hover:bg-slate-600"
                          >
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage className="text-red-400" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="documentNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">Document Number</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="text"
                      placeholder="Enter your document number"
                      className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 focus:border-blue-500"
                    />
                  </FormControl>
                  <FormMessage className="text-red-400" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="documentImageUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">Document Image (Optional)</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type="url"
                        placeholder="https://example.com/document-image.jpg"
                        className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 focus:border-blue-500 pl-10"
                      />
                      <FileText className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                    </div>
                  </FormControl>
                  <FormMessage className="text-red-400" />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="selfieImageUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-slate-300">Selfie with Document (Optional)</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        {...field}
                        type="url"
                        placeholder="https://example.com/selfie-with-document.jpg"
                        className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400 focus:border-blue-500 pl-10"
                      />
                      <Camera className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                    </div>
                  </FormControl>
                  <FormMessage className="text-red-400" />
                </FormItem>
              )}
            />

            <div className="bg-blue-900/20 border border-blue-700/50 p-4 rounded-lg">
              <h4 className="text-blue-300 font-medium mb-2">KYC Requirements</h4>
              <ul className="text-blue-200/80 text-sm space-y-1">
                <li>• Provide a valid government-issued photo ID</li>
                <li>• Document must be clear and all information visible</li>
                <li>• Selfie should clearly show your face and document</li>
                <li>• Processing typically takes 1-3 business days</li>
                <li>• For demo: Image URLs are optional - document info is sufficient</li>
              </ul>
            </div>

            <Button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              disabled={kycMutation.isPending || user?.kycStatus === 'pending'}
            >
              {kycMutation.isPending ? "Submitting KYC..." : 
               user?.kycStatus === 'pending' ? "KYC Under Review" :
               "Submit KYC Verification"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
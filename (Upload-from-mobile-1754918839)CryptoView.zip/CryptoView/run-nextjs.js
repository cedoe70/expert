#!/usr/bin/env node

const { spawn } = require('child_process');
const path = require('path');

// Start Next.js dev server pointing to the nextjs-backend directory
const nextjs = spawn('npx', ['next', 'dev', '-p', '3001'], {
  cwd: path.join(__dirname, 'nextjs-backend'),
  stdio: 'inherit',
  shell: true
});

nextjs.on('error', (err) => {
  console.error('Failed to start Next.js server:', err);
});

nextjs.on('exit', (code) => {
  console.log(`Next.js server exited with code ${code}`);
});

console.log('Starting Next.js backend server on port 3001...');
import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  loginSchema, 
  registerSchema, 
  depositSchema, 
  withdrawalSchema, 
  kycSchema 
} from "@shared/schema";
import { randomUUID } from "crypto";

// Mock data for crypto APIs
const mockCryptoData = [
  {
    rank: 1,
    name: "Bitcoin",
    symbol: "BTC",
    price: "$43,250.00",
    change: "+2.34%",
    marketCap: "$847.2B",
    volume: "$28.4B",
    isPositive: true
  },
  {
    rank: 2,
    name: "Ethereum",
    symbol: "ETH",
    price: "$2,650.00",
    change: "+1.87%",
    marketCap: "$318.7B",
    volume: "$15.2B",
    isPositive: true
  },
  {
    rank: 3,
    name: "BNB",
    symbol: "BNB",
    price: "$315.40",
    change: "-0.92%",
    marketCap: "$48.6B",
    volume: "$1.8B",
    isPositive: false
  },
  {
    rank: 4,
    name: "Cardano",
    symbol: "ADA",
    price: "$0.48",
    change: "+3.21%",
    marketCap: "$16.8B",
    volume: "$892M",
    isPositive: true
  },
  {
    rank: 5,
    name: "Solana",
    symbol: "SOL",
    price: "$95.30",
    change: "+5.67%",
    marketCap: "$41.2B",
    volume: "$2.1B",
    isPositive: true
  }
];

const mockMarketStats = {
  totalMarketCap: "$1.7T",
  volume24h: "$89.2B",
  btcDominance: "51.2%",
  activeCryptocurrencies: 2384
};

// Simple session management
interface UserSession {
  userId: string;
  username: string;
  email: string;
}

const sessions = new Map<string, UserSession>();

// Authentication middleware
function requireAuth(req: Request & { user?: UserSession }, res: Response, next: NextFunction) {
  const sessionId = req.headers['authorization']?.replace('Bearer ', '');
  
  if (!sessionId || !sessions.has(sessionId)) {
    return res.status(401).json({ success: false, message: 'Authentication required' });
  }
  
  req.user = sessions.get(sessionId);
  next();
}

// Simple password hashing (in production, use bcrypt)
function hashPassword(password: string): string {
  return Buffer.from(password).toString('base64');
}

function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({
      status: "healthy",
      timestamp: new Date().toISOString(),
      service: "CryptoFlow Express Backend"
    });
  });

  // Crypto prices endpoint (Next.js-style API)
  app.get("/api/crypto/prices", (req, res) => {
    res.json(mockCryptoData);
  });

  // Market stats endpoint (Next.js-style API)
  app.get("/api/market/stats", (req, res) => {
    res.json(mockMarketStats);
  });

  // Newsletter subscription endpoint (Next.js-style API)
  app.post("/api/newsletter/subscribe", (req, res) => {
    const { email } = req.body;
    
    if (!email || !email.includes('@')) {
      return res.status(400).json({
        success: false,
        message: "Please provide a valid email address"
      });
    }
    
    // Simulate processing delay
    setTimeout(() => {
      res.json({
        success: true,
        message: "Successfully subscribed to newsletter!"
      });
    }, 500);
  });

  // Authentication Routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ success: false, message: "Username already exists" });
      }

      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ success: false, message: "Email already exists" });
      }

      // Create new user
      const hashedPassword = hashPassword(userData.password);
      const newUser = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Create initial balances for major cryptocurrencies
      const currencies = ['BTC', 'ETH', 'BNB', 'ADA', 'SOL', 'USD'];
      for (const currency of currencies) {
        await storage.createBalance({
          userId: newUser.id,
          currency,
          balance: currency === 'USD' ? '1000.00' : '0.00000000', // Give $1000 starting balance
          availableBalance: currency === 'USD' ? '1000.00' : '0.00000000',
          lockedBalance: '0.00000000',
        });
      }

      // Create session
      const sessionId = randomUUID();
      sessions.set(sessionId, {
        userId: newUser.id,
        username: newUser.username,
        email: newUser.email,
      });

      res.json({
        success: true,
        message: "Account created successfully",
        sessionId,
        user: {
          id: newUser.id,
          username: newUser.username,
          email: newUser.email,
          kycStatus: newUser.kycStatus,
        }
      });
    } catch (error: any) {
      res.status(400).json({ 
        success: false, 
        message: error.message || "Registration failed"
      });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user || !verifyPassword(password, user.password)) {
        return res.status(401).json({ success: false, message: "Invalid credentials" });
      }

      // Create session
      const sessionId = randomUUID();
      sessions.set(sessionId, {
        userId: user.id,
        username: user.username,
        email: user.email,
      });

      res.json({
        success: true,
        message: "Login successful",
        sessionId,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          kycStatus: user.kycStatus,
        }
      });
    } catch (error: any) {
      res.status(400).json({ 
        success: false, 
        message: error.message || "Login failed"
      });
    }
  });

  app.post("/api/auth/logout", requireAuth, (req: any, res) => {
    const sessionId = req.headers['authorization']?.replace('Bearer ', '');
    if (sessionId) {
      sessions.delete(sessionId);
    }
    res.json({ success: true, message: "Logged out successfully" });
  });

  app.get("/api/auth/user", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ success: false, message: "User not found" });
      }

      const { password, ...userProfile } = user;
      res.json({
        ...userProfile,
        sessionId: req.headers['authorization']?.replace('Bearer ', '')
      });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to fetch user" });
    }
  });

  // User Dashboard Routes
  app.get("/api/user/profile", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (!user) {
        return res.status(404).json({ success: false, message: "User not found" });
      }

      const { password, ...userProfile } = user;
      res.json({ success: true, user: userProfile });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to fetch profile" });
    }
  });

  app.get("/api/user/balances", requireAuth, async (req: any, res) => {
    try {
      const balances = await storage.getUserBalances(req.user.userId);
      res.json({ success: true, balances });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to fetch balances" });
    }
  });

  app.get("/api/user/transactions", requireAuth, async (req: any, res) => {
    try {
      const transactions = await storage.getTransactions(req.user.userId);
      res.json({ success: true, transactions });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to fetch transactions" });
    }
  });

  // Deposit endpoint
  app.post("/api/user/deposit", requireAuth, async (req: any, res) => {
    try {
      const { currency, amount } = depositSchema.parse(req.body);
      const amountNum = parseFloat(amount);

      // Create transaction record
      const transaction = await storage.createTransaction({
        userId: req.user.userId,
        type: 'deposit',
        currency,
        amount,
        status: 'completed',
        txHash: `deposit_${randomUUID()}`,
        notes: `Deposit of ${amount} ${currency}`,
      });

      // Update user balance
      const existingBalance = await storage.getUserBalance(req.user.userId, currency);
      if (existingBalance) {
        const newBalance = (parseFloat(existingBalance.balance || '0') + amountNum).toString();
        const newAvailable = (parseFloat(existingBalance.availableBalance || '0') + amountNum).toString();
        
        await storage.updateBalance(req.user.userId, currency, {
          balance: newBalance,
          availableBalance: newAvailable,
        });
      }

      res.json({ 
        success: true, 
        message: `Successfully deposited ${amount} ${currency}`,
        transaction 
      });
    } catch (error: any) {
      res.status(400).json({ 
        success: false, 
        message: error.message || "Deposit failed" 
      });
    }
  });

  // Withdrawal endpoint
  app.post("/api/user/withdraw", requireAuth, async (req: any, res) => {
    try {
      const { currency, amount, address } = withdrawalSchema.parse(req.body);
      const amountNum = parseFloat(amount);

      // Check if user has sufficient balance
      const balance = await storage.getUserBalance(req.user.userId, currency);
      if (!balance || parseFloat(balance.availableBalance || '0') < amountNum) {
        return res.status(400).json({ 
          success: false, 
          message: "Insufficient balance" 
        });
      }

      // Create transaction record
      const transaction = await storage.createTransaction({
        userId: req.user.userId,
        type: 'withdrawal',
        currency,
        amount,
        status: 'pending',
        address,
        txHash: `withdrawal_${randomUUID()}`,
        notes: `Withdrawal of ${amount} ${currency} to ${address}`,
      });

      // Update user balance
      const newAvailable = (parseFloat(balance.availableBalance || '0') - amountNum).toString();
      const newLocked = (parseFloat(balance.lockedBalance || '0') + amountNum).toString();
      
      await storage.updateBalance(req.user.userId, currency, {
        availableBalance: newAvailable,
        lockedBalance: newLocked,
      });

      res.json({ 
        success: true, 
        message: `Withdrawal request submitted for ${amount} ${currency}`,
        transaction 
      });
    } catch (error: any) {
      res.status(400).json({ 
        success: false, 
        message: error.message || "Withdrawal failed" 
      });
    }
  });

  // KYC Routes
  app.get("/api/user/kyc", requireAuth, async (req: any, res) => {
    try {
      const kycSubmission = await storage.getKycSubmission(req.user.userId);
      res.json({ success: true, kyc: kycSubmission });
    } catch (error) {
      res.status(500).json({ success: false, message: "Failed to fetch KYC status" });
    }
  });

  app.post("/api/user/kyc", requireAuth, async (req: any, res) => {
    try {
      const kycData = kycSchema.parse(req.body);

      // Check if KYC already submitted
      const existingKyc = await storage.getKycSubmission(req.user.userId);
      if (existingKyc && existingKyc.status !== 'rejected') {
        return res.status(400).json({ 
          success: false, 
          message: "KYC already submitted or approved" 
        });
      }

      // Create KYC submission
      const kycSubmission = await storage.createKycSubmission({
        userId: req.user.userId,
        ...kycData,
        status: 'pending',
      });

      // Update user KYC status
      await storage.updateUser(req.user.userId, {
        kycStatus: 'pending',
      });

      res.json({ 
        success: true, 
        message: "KYC submitted successfully. Review typically takes 1-3 business days.",
        kyc: kycSubmission 
      });
    } catch (error: any) {
      res.status(400).json({ 
        success: false, 
        message: error.message || "KYC submission failed" 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}

import { 
  users, 
  userBalances, 
  transactions, 
  kycSubmissions,
  type User, 
  type InsertUser,
  type UserBalance,
  type InsertUserBalance,
  type Transaction,
  type InsertTransaction,
  type KycSubmission,
  type InsertKycSubmission
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;
  
  // Balance operations
  getUserBalances(userId: string): Promise<UserBalance[]>;
  getUserBalance(userId: string, currency: string): Promise<UserBalance | undefined>;
  createBalance(balance: InsertUserBalance): Promise<UserBalance>;
  updateBalance(userId: string, currency: string, updates: Partial<UserBalance>): Promise<UserBalance>;
  
  // Transaction operations
  getTransactions(userId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: string, updates: Partial<Transaction>): Promise<Transaction>;
  
  // KYC operations
  getKycSubmission(userId: string): Promise<KycSubmission | undefined>;
  createKycSubmission(kyc: InsertKycSubmission): Promise<KycSubmission>;
  updateKycSubmission(id: string, updates: Partial<KycSubmission>): Promise<KycSubmission>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // Balance operations
  async getUserBalances(userId: string): Promise<UserBalance[]> {
    return await db.select().from(userBalances).where(eq(userBalances.userId, userId));
  }

  async getUserBalance(userId: string, currency: string): Promise<UserBalance | undefined> {
    const [balance] = await db
      .select()
      .from(userBalances)
      .where(and(eq(userBalances.userId, userId), eq(userBalances.currency, currency)));
    return balance || undefined;
  }

  async createBalance(balance: InsertUserBalance): Promise<UserBalance> {
    const [newBalance] = await db.insert(userBalances).values(balance).returning();
    return newBalance;
  }

  async updateBalance(userId: string, currency: string, updates: Partial<UserBalance>): Promise<UserBalance> {
    const [updatedBalance] = await db
      .update(userBalances)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(userBalances.userId, userId), eq(userBalances.currency, currency)))
      .returning();
    return updatedBalance;
  }

  // Transaction operations
  async getTransactions(userId: string): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(transactions.createdAt);
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [newTransaction] = await db.insert(transactions).values(transaction).returning();
    return newTransaction;
  }

  async updateTransaction(id: string, updates: Partial<Transaction>): Promise<Transaction> {
    const [updatedTransaction] = await db
      .update(transactions)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(transactions.id, id))
      .returning();
    return updatedTransaction;
  }

  // KYC operations
  async getKycSubmission(userId: string): Promise<KycSubmission | undefined> {
    const [kycSubmission] = await db
      .select()
      .from(kycSubmissions)
      .where(eq(kycSubmissions.userId, userId));
    return kycSubmission || undefined;
  }

  async createKycSubmission(kyc: InsertKycSubmission): Promise<KycSubmission> {
    const [newKyc] = await db.insert(kycSubmissions).values(kyc).returning();
    return newKyc;
  }

  async updateKycSubmission(id: string, updates: Partial<KycSubmission>): Promise<KycSubmission> {
    const [updatedKyc] = await db
      .update(kycSubmissions)
      .set(updates)
      .where(eq(kycSubmissions.id, id))
      .returning();
    return updatedKyc;
  }
}

export const storage = new DatabaseStorage();

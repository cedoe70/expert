import type { NextApiRequest, NextApiResponse } from 'next'

type MarketStats = {
  totalMarketCap: string
  volume24h: string
  btcDominance: string
  activeCryptocurrencies: number
}

const mockMarketStats: MarketStats = {
  totalMarketCap: "$1.7T",
  volume24h: "$89.2B",
  btcDominance: "51.2%",
  activeCryptocurrencies: 2384
}

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<MarketStats | { error: string }>
) {
  if (req.method === 'GET') {
    res.status(200).json(mockMarketStats)
  } else {
    res.setHeader('Allow', ['GET'])
    res.status(405).json({ error: `Method ${req.method} Not Allowed` })
  }
}
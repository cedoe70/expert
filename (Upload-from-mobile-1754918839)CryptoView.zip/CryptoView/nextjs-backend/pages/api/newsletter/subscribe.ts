import type { NextApiRequest, NextApiResponse } from 'next'

type SubscribeRequest = {
  email: string
}

type SubscribeResponse = {
  success: boolean
  message: string
}

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<SubscribeResponse>
) {
  if (req.method === 'POST') {
    const { email } = req.body as SubscribeRequest
    
    // Basic email validation
    if (!email || !email.includes('@')) {
      return res.status(400).json({
        success: false,
        message: "Please provide a valid email address"
      })
    }
    
    // Simulate processing delay
    setTimeout(() => {
      res.status(200).json({
        success: true,
        message: "Successfully subscribed to newsletter!"
      })
    }, 500)
    
  } else {
    res.setHeader('Allow', ['POST'])
    res.status(405).json({
      success: false,
      message: `Method ${req.method} Not Allowed`
    })
  }
}
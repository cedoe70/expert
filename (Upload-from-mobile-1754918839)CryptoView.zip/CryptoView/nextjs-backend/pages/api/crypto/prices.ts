import type { NextApiRequest, NextApiResponse } from 'next'

type CryptoPriceData = {
  symbol: string
  name: string
  price: string
  change: string
  isPositive: boolean
  marketCap: string
  volume: string
  rank: number
}

const mockCryptoData: CryptoPriceData[] = [
  {
    rank: 1,
    name: "Bitcoin",
    symbol: "BTC",
    price: "$43,250.00",
    change: "+2.34%",
    marketCap: "$847.2B",
    volume: "$28.4B",
    isPositive: true
  },
  {
    rank: 2,
    name: "Ethereum",
    symbol: "ETH",
    price: "$2,650.00",
    change: "+1.87%",
    marketCap: "$318.7B",
    volume: "$15.2B",
    isPositive: true
  },
  {
    rank: 3,
    name: "BNB",
    symbol: "BNB",
    price: "$315.40",
    change: "-0.92%",
    marketCap: "$48.6B",
    volume: "$1.8B",
    isPositive: false
  },
  {
    rank: 4,
    name: "Cardano",
    symbol: "ADA",
    price: "$0.48",
    change: "+3.21%",
    marketCap: "$16.8B",
    volume: "$892M",
    isPositive: true
  },
  {
    rank: 5,
    name: "Solana",
    symbol: "SOL",
    price: "$95.30",
    change: "+5.67%",
    marketCap: "$41.2B",
    volume: "$2.1B",
    isPositive: true
  }
]

export default function handler(
  req: NextApiRequest,
  res: NextApiResponse<CryptoPriceData[] | { error: string }>
) {
  if (req.method === 'GET') {
    // In a real application, you would fetch data from a crypto API like CoinGecko
    // For now, we'll return mock data
    res.status(200).json(mockCryptoData)
  } else {
    res.setHeader('Allow', ['GET'])
    res.status(405).json({ error: `Method ${req.method} Not Allowed` })
  }
}
# CryptoFlow - Cryptocurrency Trading Platform

## Overview

CryptoFlow is a modern cryptocurrency trading platform built as a full-stack web application. It provides users with a comprehensive interface for trading, investing, and managing digital assets. The application features a sleek dark-themed UI with real-time market data, advanced charting capabilities, and a complete trading ecosystem designed for both novice and experienced cryptocurrency traders.

The platform showcases modern web development practices with a React-based frontend, Express.js backend, and PostgreSQL database integration. It's designed to be scalable, secure, and user-friendly while maintaining professional trading platform standards.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side application is built using **React 18** with **TypeScript** for type safety and better development experience. The architecture follows modern React patterns:

- **Component-based structure**: Uses a modular component approach with reusable UI components
- **Styling system**: Implements **Tailwind CSS** with a custom design system featuring CSS variables for theming
- **UI component library**: Built on **Radix UI** primitives with shadcn/ui components for accessibility and consistency
- **Routing**: Uses **wouter** for lightweight client-side routing
- **State management**: Leverages **TanStack Query (React Query)** for server state management and caching
- **Form handling**: Integrates **React Hook Form** with **Zod** for form validation
- **Build system**: **Vite** for fast development and optimized production builds

### Backend Architecture
The server-side is built with **Node.js** and **Express.js** following REST API principles:

- **Runtime**: Modern Node.js with ES modules support
- **Web framework**: Express.js with TypeScript for type-safe API development
- **Development setup**: Hot reload support with tsx for TypeScript execution
- **API structure**: RESTful endpoints with /api prefix for clear separation
- **Error handling**: Centralized error handling middleware
- **Request logging**: Comprehensive request/response logging for API endpoints

### Database Architecture
The application uses **PostgreSQL** as the primary database with **Drizzle ORM** for type-safe database operations:

- **Database**: PostgreSQL for robust relational data storage
- **ORM**: Drizzle ORM with TypeScript integration for schema definition and queries
- **Database client**: Neon Database serverless driver for cloud-native PostgreSQL
- **Schema management**: Drizzle Kit for migrations and schema synchronization
- **Type safety**: Full TypeScript integration with inferred types from database schema

### Data Storage Strategy
The application implements a flexible storage abstraction:

- **Storage interface**: Abstract IStorage interface for CRUD operations
- **Development storage**: In-memory storage implementation for development and testing
- **User management**: Basic user model with username/password authentication
- **Scalable design**: Interface allows easy swapping between storage implementations

### Authentication & Security
Basic user authentication system with extensible design:

- **User model**: Simple user schema with unique usernames
- **Password storage**: Prepared for secure password hashing implementation
- **Session management**: Uses connect-pg-simple for PostgreSQL session storage
- **Type validation**: Zod schemas for request/response validation

### UI/UX Design System
Comprehensive design system built on modern CSS practices:

- **Design tokens**: CSS custom properties for consistent theming
- **Color palette**: Dark theme optimized for trading applications
- **Typography**: Inter font family for modern, readable interface
- **Component library**: Complete set of accessible UI components
- **Responsive design**: Mobile-first approach with breakpoint-based layouts
- **Animation system**: Smooth transitions and micro-interactions

### Development & Deployment
Modern development workflow with production-ready build process:

- **Development server**: Vite dev server with HMR for rapid development
- **Build pipeline**: Separate client and server build processes
- **Code quality**: TypeScript for type safety across the entire stack
- **Asset handling**: Vite-based asset optimization and bundling

## External Dependencies

### Core Framework Dependencies
- **@vitejs/plugin-react**: React plugin for Vite build system
- **express**: Fast, unopinionated web framework for Node.js
- **react**: Core React library for building user interfaces
- **typescript**: TypeScript compiler for type-safe JavaScript

### Database & ORM
- **@neondatabase/serverless**: Serverless PostgreSQL driver for Neon Database
- **drizzle-orm**: Lightweight TypeScript ORM with excellent performance
- **drizzle-kit**: CLI companion for database migrations and introspection
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### UI & Styling
- **@radix-ui/react-***: Collection of accessible, unstyled UI primitives
- **tailwindcss**: Utility-first CSS framework for rapid UI development
- **class-variance-authority**: Utility for creating component variants
- **clsx**: Utility for constructing className strings conditionally

### State Management & Data Fetching
- **@tanstack/react-query**: Powerful data synchronization for React applications
- **react-hook-form**: Performant, flexible forms with easy validation
- **@hookform/resolvers**: Validation resolvers for React Hook Form

### Routing & Navigation
- **wouter**: Minimalist routing library for React applications

### Validation & Schema
- **zod**: TypeScript-first schema validation with static type inference
- **drizzle-zod**: Integration between Drizzle ORM and Zod for schema validation

### Development Tools
- **tsx**: TypeScript execute for Node.js development
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay
- **@replit/vite-plugin-cartographer**: Development tooling for Replit environment

### Utilities & Icons
- **date-fns**: Modern JavaScript date utility library
- **lucide-react**: Beautiful & consistent icon toolkit
- **react-icons**: Popular icon libraries for React
- **cmdk**: Fast, composable, unstyled command menu for React
- **embla-carousel-react**: Extensible low-level carousel for React
- **nanoid**: Tiny, secure, URL-friendly unique string ID generator

### Build & Bundling
- **esbuild**: Extremely fast JavaScript bundler for server-side code
- **autoprefixer**: CSS post-processor for vendor prefixing
- **postcss**: Tool for transforming CSS with JavaScript

The application integrates with **Neon Database** for cloud-native PostgreSQL hosting and is optimized for deployment on **Replit** with specialized development plugins.
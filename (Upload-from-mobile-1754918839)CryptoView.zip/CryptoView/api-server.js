import express from 'express';
import cors from 'cors';
const app = express();

// Enable CORS for frontend
app.use(cors());
app.use(express.json());

// Mock data
const mockCryptoData = [
  {
    rank: 1,
    name: "Bitcoin",
    symbol: "BTC",
    price: "$43,250.00",
    change: "+2.34%",
    marketCap: "$847.2B",
    volume: "$28.4B",
    isPositive: true
  },
  {
    rank: 2,
    name: "Ethereum",
    symbol: "ETH",
    price: "$2,650.00",
    change: "+1.87%",
    marketCap: "$318.7B",
    volume: "$15.2B",
    isPositive: true
  },
  {
    rank: 3,
    name: "BNB",
    symbol: "BNB",
    price: "$315.40",
    change: "-0.92%",
    marketCap: "$48.6B",
    volume: "$1.8B",
    isPositive: false
  },
  {
    rank: 4,
    name: "Cardano",
    symbol: "ADA",
    price: "$0.48",
    change: "+3.21%",
    marketCap: "$16.8B",
    volume: "$892M",
    isPositive: true
  },
  {
    rank: 5,
    name: "Solana",
    symbol: "SOL",
    price: "$95.30",
    change: "+5.67%",
    marketCap: "$41.2B",
    volume: "$2.1B",
    isPositive: true
  }
];

const mockMarketStats = {
  totalMarketCap: "$1.7T",
  volume24h: "$89.2B",
  btcDominance: "51.2%",
  activeCryptocurrencies: 2384
};

// API Routes
app.get('/api/health', (req, res) => {
  res.json({
    status: "healthy",
    timestamp: new Date().toISOString(),
    service: "CryptoFlow Next.js-style Backend"
  });
});

app.get('/api/crypto/prices', (req, res) => {
  res.json(mockCryptoData);
});

app.get('/api/market/stats', (req, res) => {
  res.json(mockMarketStats);
});

app.post('/api/newsletter/subscribe', (req, res) => {
  const { email } = req.body;
  
  if (!email || !email.includes('@')) {
    return res.status(400).json({
      success: false,
      message: "Please provide a valid email address"
    });
  }
  
  // Simulate processing delay
  setTimeout(() => {
    res.json({
      success: true,
      message: "Successfully subscribed to newsletter!"
    });
  }, 500);
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`🚀 Next.js-style API server running on http://localhost:${PORT}`);
});

export default app;